package com.suiqu.cloud.service;

import com.suiqu.cloud.entity.FileIndex;
import com.suiqu.cloud.mapper.FileUserMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class ElasticsearchSyncService {

    @Autowired
    private FileUserMapper fileUserMapper;

    @Autowired
    private ElasticsearchOperations esOperations;

    public void syncAllData() {
        log.info(">>> 开始同步 MySQL 数据到 Elasticsearch...");

        try {
            // 1. 从 MySQL 获取所有需要索引的数据
            // 注意：如果数据量达到百万级，建议改用 MyBatis-Plus 的分页查询
            List<FileIndex> allFiles = fileUserMapper.selectAllForSync();

            if (allFiles.isEmpty()) {
                log.info(">>> MySQL 中无文件数据，跳过同步。");
                return;
            }

            // 2. 批量保存到 ES
            // save 方法会自动处理：ID 存在则更新，不存在则插入（Upsert）
            esOperations.save(allFiles);

            log.info(">>> 数据同步成功，共同步 {} 条记录。", allFiles.size());
        } catch (Exception e) {
            log.error(">>> 数据同步到 ES 失败: ", e);
        }
    }
}