package com.suiqu.cloud.mq;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.suiqu.cloud.config.RabbitConfig;
import com.suiqu.cloud.entity.FileIndex;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.stereotype.Component;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class FileSyncConsumer {
    @Autowired
    private ElasticsearchOperations esOperations;

    @RabbitListener(queues = RabbitConfig.SYNC_QUEUE)
    public void handleCanalMessage(String message) {
        log.info("收到 Canal 同步消息: {}", message);
        JSONObject json = JSON.parseObject(message);

        // 1. 判断是否DDL语句(建库、建表、删表等)，DDL消息data一定为null，直接ACK丢弃不处理
        Boolean isDdl = json.getBoolean("isDdl");
        if (Boolean.TRUE.equals(isDdl)) {
            log.info("当前为DDL语句，跳过ES同步，sql:{}", json.getString("sql"));
            return;
        }

        // 2. 非DDL，获取data并做空判断，避免null调用size()空指针
        JSONArray data = json.getJSONArray("data");
        if (data == null || data.isEmpty()) {
            log.warn("Canal消息data为空，跳过处理");
            return;
        }

        // 3. 正常DML(INSERT/UPDATE/DELETE)执行ES同步
        String type = json.getString("type");
        for (int i = 0; i < data.size(); i++) {
            FileIndex index = data.getObject(i, FileIndex.class);
            if ("DELETE".equals(type)) {
                esOperations.delete(index.getId().toString(), FileIndex.class);
            } else {
                esOperations.save(index);
            }
        }
    }
}